package com.example.aula_1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aula_1.ui.theme.Aula_1Theme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            Aula_1Theme {

                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->

                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(
    name: String,
    modifier: Modifier = Modifier
) {

    var contador by remember { mutableStateOf(0) }
    var textoDigitado by remember { mutableStateOf("") }
    var lista by remember { mutableStateOf(listOf<String>()) }
    var modoEscuro by remember { mutableStateOf(true) }
    var mensagemErro by remember { mutableStateOf("") }

    val corTexto = Color.White

    Box(
        modifier = modifier.fillMaxSize()
    ) {

        Image(
            painter = painterResource(id = R.drawable.android),
            contentDescription = "Fundo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.50f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),

            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Android Compose",
                color = corTexto,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            // ==================================================
            // EXERCÍCIO 1
            // CRIAR UMA ROW COM 3 BOTÕES
            // ==================================================

            Row(
                modifier = Modifier.fillMaxWidth(), // Row ocupa largura total
                horizontalArrangement = Arrangement.SpaceEvenly, // espaço igual entre botões
                verticalAlignment = Alignment.CenterVertically // centraliza verticalmente
            ) {

                Button(
                    onClick = {} // ação ao clicar
                ) {
                    Text(
                        text = "Perfil" // texto do botão
                    )
                }

                Button(
                    onClick = {} // ação ao clicar
                ) {
                    Text(
                        text = "Configurações" // texto do botão
                    )
                }

                Button(
                    onClick = {} // ação ao clicar
                ) {
                    Text(
                        text = "Sair" // texto do botão
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço vertical após exercício 1
            )

            // ==================================================
            // EXERCÍCIO 2
            // CARD COM COLUMN E 3 TEXTOS
            // ==================================================

            Card(
                modifier = Modifier.fillMaxWidth() // Card ocupa largura total
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxWidth() // Column ocupa largura total
                        .padding(12.dp), // espaço interno de 12dp

                    horizontalAlignment =
                        Alignment.CenterHorizontally // centraliza textos
                ) {

                    Text(
                        text = "Nome: Amanda Silva" // primeira linha
                    )

                    Text(
                        text = "Curso: Sistemas de Informação" // segunda linha
                    )

                    Text(
                        text = "Semestre: 1º" // terceira linha
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço vertical após exercício 2
            )

            // ==================================================
            // EXERCÍCIO EXTRA
            // CAMPO DE TEXTO
            // ==================================================

            OutlinedTextField(
                value = textoDigitado, // valor atual do campo

                onValueChange = { // executa ao digitar
                    textoDigitado = it // salva texto digitado

                    mensagemErro =
                        if (it.length > 20) // se maior que 20 letras
                            "Texto muito longo!" // mensagem erro
                        else
                            "" // sem erro
                },

                label = {
                    Text(
                        "Digite algo" // texto interno do label
                    )
                },

                isError = mensagemErro.isNotEmpty(), // borda vermelha se erro

                modifier = Modifier.fillMaxWidth() // largura total
            )

            if (mensagemErro.isNotEmpty()) { // se houver erro

                Text(
                    text = mensagemErro, // mostra erro
                    color = Color.Red // vermelho
                )
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço abaixo do campo
            )

            // ==================================================
            // EXERCÍCIO EXTRA
            // BOTÕES ADICIONAR E LIMPAR
            // ==================================================

            Row(
                modifier = Modifier.fillMaxWidth(), // largura total

                horizontalArrangement =
                    Arrangement.SpaceEvenly // espaço igual
            ) {

                Button(
                    onClick = {

                        if (textoDigitado.isNotBlank()) { // se texto não vazio

                            lista = lista + textoDigitado // adiciona item

                            contador++ // soma contador

                            textoDigitado = "" // limpa campo
                        }
                    }
                ) {
                    Text(
                        text = "Adicionar" // texto botão
                    )
                }

                Button(
                    onClick = {

                        lista = emptyList() // limpa lista

                        contador = 0 // zera contador
                    }
                ) {
                    Text(
                        text = "Limpar" // texto botão
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço abaixo botões
            )

            // ==================================================
            // EXERCÍCIO EXTRA
            // SWITCH
            // ==================================================

            Row(
                verticalAlignment =
                    Alignment.CenterVertically // centraliza verticalmente
            ) {

                Text(
                    text = "Modo Escuro", // texto do switch
                    color = Color.White // branco
                )

                Spacer(
                    modifier = Modifier.width(8.dp) // espaço horizontal
                )

                Switch(
                    checked = modoEscuro, // valor atual true/false

                    onCheckedChange = {
                        modoEscuro = it // troca valor
                    }
                )
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço abaixo switch
            )

            Text(
                text = "Itens adicionados: $contador", // mostra contador

                color =
                    if (contador > 5) // se maior que 5
                        Color.Green // verde
                    else
                        Color.White, // branco

                fontSize = 18.sp // tamanho fonte
            )

            Spacer(
                modifier = Modifier.height(12.dp) // espaço abaixo contador
            )

            // ==================================================
            // EXERCÍCIO 3
            // BOX CENTRALIZADO COM TEXTO
            // ==================================================

            Box(
                modifier = Modifier
                    .fillMaxWidth() // largura total
                    .height(100.dp) // altura fixa
                    .background(Color.Blue), // fundo azul

                contentAlignment = Alignment.Center // centraliza conteúdo
            ) {

                Text(
                    text = "Área de Avisos", // texto interno
                    color = Color.White, // cor branca
                    fontWeight = FontWeight.Bold // negrito
                )
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço após exercício 3
            )

            // ==================================================
            // EXERCÍCIO 4
            // ROW COM IMAGEM TEXTO E BOTÃO
            // ==================================================

            Row(
                modifier = Modifier.fillMaxWidth(), // largura total

                verticalAlignment =
                    Alignment.CenterVertically, // centraliza altura

                horizontalArrangement =
                    Arrangement.SpaceEvenly // espaço igual
            ) {

                Image(
                    painter = painterResource(
                        id = R.drawable.android
                    ), // busca imagem

                    contentDescription = "Mini imagem", // descrição acessibilidade

                    modifier = Modifier.size(40.dp) // tamanho 40dp
                )

                Text(
                    text = "Jetpack Compose", // texto central
                    color = Color.White // branco
                )

                Button(
                    onClick = {} // clique vazio
                ) {
                    Text(
                        text = "Abrir" // texto botão
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço após exercício 4
            )

            // ==================================================
            // EXERCÍCIO 5
            // CARD COM FOR
            // ==================================================

            Card(
                modifier = Modifier.fillMaxWidth() // largura total
            ) {

                Column(
                    modifier = Modifier.padding(12.dp) // espaço interno
                ) {

                    for (i in 1..5) { // repete de 1 até 5

                        Text(
                            text = "Item $i" // mostra Item 1 até Item 5
                        )
                    }
                }
            }

            Spacer(
                modifier = Modifier.height(12.dp) // espaço após exercício 5
            )

            LazyColumn(
                modifier = Modifier.height(150.dp) // altura da lista
            ) {

                itemsIndexed(lista) { index, item -> // índice e item

                    Row(
                        modifier = Modifier
                            .fillMaxWidth() // largura total
                            .padding(6.dp), // espaço interno

                        horizontalArrangement =
                            Arrangement.SpaceBetween // um em cada lado
                    ) {

                        Text(
                            text = item // mostra item
                        )

                        Button(
                            onClick = {

                                lista =
                                    lista.toMutableList()
                                        .also {
                                            it.removeAt(index) // remove item
                                        }
                            }
                        ) {
                            Text(
                                text = "Remover" // texto botão
                            )
                        }
                    }
                }
            }

            if (contador >= 10) { // se contador 10 ou mais

                Text(
                    text = "🔥 Você está usando muito bem o app!",
                    color = Color.Magenta,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewApp() {
    Aula_1Theme {
        Greeting("Android")
    }
}